# LDGplants_rates
R code for the manuscript "Angiosperm speciation cools down in the tropics " by Javier Igea and Andrew J. Tanentzap  - in press in  Ecology Letters; also on biorxiv
