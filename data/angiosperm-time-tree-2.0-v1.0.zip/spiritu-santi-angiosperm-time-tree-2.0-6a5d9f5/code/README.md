# Scripts
The following script contains the necessary code to perforn all the analyses presented in Ramírez-Barahona et al. (2020).
The scripts in the folder 'final_analyses' are serialized.

WARNING (NOTE TO SELF): all the code works with the files provided, but most is very messy. 
The code needs to be improved and many tasks are not optimized in terms of processing. 
Also there is still quite a lot of automation left to do.
